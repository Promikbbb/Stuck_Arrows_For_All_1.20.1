package traben.entity_pin_cushions;

import com.mojang.datafixers.util.Pair;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1667;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4592;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5597;
import net.minecraft.class_5617;
import net.minecraft.class_5819;
import net.minecraft.class_583;
import net.minecraft.class_630;
import net.minecraft.class_7198;
import net.minecraft.class_7833;
import net.minecraft.class_898;
import net.minecraft.class_922;

public abstract class PinCushionLayer<T extends class_1309, M extends class_583<T>> extends class_3887<T, M> {
    public PinCushionLayer(class_922<T, M> renderer) {
        super(renderer);
    }

    protected abstract int numStuck(T entity);

    protected abstract void renderStuckItem(class_4587 poseStack, class_4597 buffer, int packedLight, class_1297 entity, float x, float y, float z, float partialTick);

    public void render(class_4587 poseStack, class_4597 buffer, int packedLight, T livingEntity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
        int i = this.numStuck(livingEntity);
        class_5819 randomSource = class_5819.method_43049(livingEntity.method_5628());
        if (i > 0) {
            for (int j = 0; j < i; ++j) {
                Random partRand = new Random(j);
                poseStack.method_22903();
                M model = method_17165();
                Pair<class_630, Runnable> modelPart = null;
                
                if (model instanceof class_4592<?> animal) {
                    modelPart = bestFromList(animal.method_22946(), animal.method_22948(), partRand, poseStack);
                } else if (model instanceof class_7198<?> frogModel) {
                    modelPart = bestFromListMutable(new ArrayList<>(Collections.singleton(frogModel.method_32008())), partRand, poseStack, true);
                } else if (model instanceof class_5597<?> hierarchicalModel) {
                    modelPart = bestFromListMutable(new ArrayList<>(hierarchicalModel.method_32008().field_3661.values()), partRand, poseStack, true);
                }

                if (modelPart == null) {
                    poseStack.method_22909();
                    return;
                }

                modelPart.getSecond().run();

                float f = randomSource.method_43057();
                float g = randomSource.method_43057();
                float h = randomSource.method_43057();

                if (!modelPart.getFirst().field_3663.isEmpty()) {
                    class_630.class_628 cube = modelPart.getFirst().method_22700(randomSource);
                    float k = class_3532.method_16439(f, cube.field_3645, cube.field_3648) / 16.0F;
                    float l = class_3532.method_16439(g, cube.field_3644, cube.field_3647) / 16.0F;
                    float m = class_3532.method_16439(h, cube.field_3643, cube.field_3646) / 16.0F;
                    poseStack.method_46416(k, l, m);
                }

                f = -1.0F * (f * 2.0F - 1.0F);
                g = -1.0F * (g * 2.0F - 1.0F);
                h = -1.0F * (h * 2.0F - 1.0F);
                this.renderStuckItem(poseStack, buffer, packedLight, livingEntity, f, g, h, partialTicks);
                poseStack.method_22909();
            }
        }
    }

    @Nullable
    private Pair<class_630, Runnable> bestFromList(Iterable<class_630> part1, Iterable<class_630> part2, Random randomSource, class_4587 poseStack) {
        List<class_630> list = new ArrayList<>();
        part1.forEach(list::add);
        part2.forEach(list::add);
        return bestFromListMutable(list, randomSource, poseStack, true);
    }

    @Nullable
    private Pair<class_630, Runnable> bestFromListMutable(List<class_630> partsMutable, Random randomSource, class_4587 poseStack, boolean firstIteration) {
        Collections.shuffle(partsMutable, randomSource);
        for (class_630 modelPart : partsMutable) {
            if (modelPart.field_3665) {
                if (!modelPart.field_3663.isEmpty() && !modelPart.field_38456) {
                    return Pair.of(modelPart, () -> modelPart.method_22703(poseStack));
                }
                if (modelPart.field_3661.isEmpty()) continue;

                var child = bestFromListMutable(new ArrayList<>(modelPart.field_3661.values()), randomSource, poseStack, false);
                if (child != null) {
                    var runnable = child.getSecond();
                    return Pair.of(child.getFirst(), () -> {
                        modelPart.method_22703(poseStack);
                        runnable.run();
                    });
                }
            }
        }
        if (firstIteration && !partsMutable.isEmpty()) {
            var part = partsMutable.get(0);
            return Pair.of(part, () -> part.method_22703(poseStack));
        }
        return null;
    }

    public static class ArrowLayer<T extends class_1309, M extends class_583<T>> extends PinCushionLayer<T, M> {
        private final class_898 dispatcher;

        public ArrowLayer(class_5617.class_5618 context, class_922<T, M> renderer) {
            super(renderer);
            this.dispatcher = context.method_32166();
        }

        protected int numStuck(T entity) {
            return entity.method_6022();
        }

        protected void renderStuckItem(class_4587 poseStack, class_4597 buffer, int packedLight, class_1297 entity, float x, float y, float z, float partialTick) {
            float f = class_3532.method_15355(x * x + z * z);
            // Fix Arrow 1.20.1
            class_1667 arrow = new class_1667(entity.method_37908(), entity.method_23317(), entity.method_23318(), entity.method_23321());
            arrow.method_36456((float) (Math.atan2(x, z) * 57.2957763671875));
            arrow.method_36457((float) (Math.atan2(y, f) * 57.2957763671875));
            arrow.field_5982 = arrow.method_36454();
            arrow.field_6004 = arrow.method_36455();
            this.dispatcher.method_3954(arrow, 0.0, 0.0, 0.0, 0.0F, partialTick, poseStack, buffer, packedLight);
        }
    }

    public static class BeeStingerLayer<T extends class_1309, M extends class_583<T>> extends PinCushionLayer<T, M> {
        //  Fix ResourceLocation 1.20.1
        private static final class_2960 BEE_STINGER_LOCATION = new class_2960("textures/entity/bee/bee_stinger.png");

        public BeeStingerLayer(class_922<T, M> renderer) {
            super(renderer);
        }

        protected int numStuck(T entity) {
            return entity.method_21753();
        }

        protected void renderStuckItem(class_4587 poseStack, class_4597 buffer, int packedLight, class_1297 entity, float x, float y, float z, float partialTick) {
            float f = class_3532.method_15355(x * x + z * z);
            float g = (float) (Math.atan2(x, z) * 57.2957763671875);
            float h = (float) (Math.atan2(y, f) * 57.2957763671875);
            poseStack.method_46416(0.0F, 0.0F, 0.0F);
            poseStack.method_22907(class_7833.field_40716.rotationDegrees(g - 90.0F));
            poseStack.method_22907(class_7833.field_40718.rotationDegrees(h));
            poseStack.method_22907(class_7833.field_40714.rotationDegrees(45.0F));
            poseStack.method_22905(0.03125F, 0.03125F, 0.03125F);
            poseStack.method_46416(2.5F, 0.0F, 0.0F);
            class_4588 vertexConsumer = buffer.getBuffer(class_1921.method_23578(BEE_STINGER_LOCATION));

            for (int n = 0; n < 4; ++n) {
                poseStack.method_22907(class_7833.field_40714.rotationDegrees(90.0F));
                class_4587.class_4665 pose = poseStack.method_23760();
                vertex(vertexConsumer, pose, -4.5F, -1, 0.0F, 0.0F, packedLight);
                vertex(vertexConsumer, pose, 4.5F, -1, 0.125F, 0.0F, packedLight);
                vertex(vertexConsumer, pose, 4.5F, 1, 0.125F, 0.0625F, packedLight);
                vertex(vertexConsumer, pose, -4.5F, 1, 0.0F, 0.0625F, packedLight);
            }
        }

        // Fix vertex 1.20.1
        private static void vertex(class_4588 consumer, class_4587.class_4665 pose, float x, int y, float u, float v, int packedLight) {
            consumer.method_22918(pose.method_23761(), x, (float) y, 0.0F)
                    .method_1336(255, 255, 255, 255)
                    .method_22913(u, v)
                    .method_22922(class_4608.field_21444)
                    .method_22916(packedLight)
                    .method_23763(pose.method_23762(), 0.0F, 1.0F, 0.0F)
                    .method_1344();
        }
    }
}