package traben.entity_pin_cushions.mixin;

import net.minecraft.class_1309;
import net.minecraft.class_3887;
import net.minecraft.class_4592;
import net.minecraft.class_4840;
import net.minecraft.class_5597;
import net.minecraft.class_5617;
import net.minecraft.class_583;
import net.minecraft.class_591;
import net.minecraft.class_922;
import net.minecraft.client.model.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import traben.entity_pin_cushions.PinCushionLayer;

@Mixin(value = class_922.class,priority = 2000)
public abstract class MixinAddLayer<T extends class_1309, M extends class_583<T>> {

    @Shadow protected M model;

    @Shadow protected abstract boolean addLayer(final class_3887<T, M> layer);

    @Inject(method = "<init>", at = @At(value = "TAIL"))
    private void allStuckArrows$mixin(final class_5617.class_5618 context, final class_583<?> model, final float shadowRadius, final CallbackInfo ci) {
        if ((this.model instanceof class_4592<?> || this.model instanceof class_5597<?>)
                && (this.model instanceof class_4840<?> || !(this.model instanceof class_591<?>))){
            try {
                class_922<T, M> self = (class_922) (Object) this;
                addLayer(new PinCushionLayer.ArrowLayer<>(context, self));
                addLayer(new PinCushionLayer.BeeStingerLayer<>(self));
            } catch (Exception e) {
                System.out.println("Failed to add custom stuck arrows layer to " + this.getClass().getName());
            }
        }
    }
}
